<?php

/*
 * This page contains all function to list the payments using wp_list_table
 * function
*/

require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');


class NMAPaymentsList extends WP_List_Table{
 
 // define data set for WP_List_Table => data
 
 public function get_payments_list_data($orderby,$order,$search_term){
     
     if($orderby=='')$payments_orderby = 'id';
     else $payments_orderby = $orderby;
     
     if($order=='')$payments_order = 'asc';
     else $payments_order = $order;
     
     $all_sanitized_payments = array();
     
     if(!empty($search_term)){
          $payments = pods('payment', array('orderby' => $payments_orderby.' '.$payments_order, 'limit' => -1, 'where' => 'payer.display_name LIKE "%' . $search_term . '%" OR author.display_name LIKE "%' . $search_term . '%" OR t.id LIKE "%' . $search_term . '%" OR house_no.house_no LIKE "%' . $search_term . '%" OR t.id LIKE "%' . $search_term . '%" OR amount LIKE "%' . $search_term . '%"'));
     }else {
         $payments = pods('payment', array('orderby' => $payments_orderby.' '.$payments_order, 'limit' => -1));
     }
     
    
     $all_payments = $payments->export_data();
     foreach($all_payments as $payment){
         $house_info = array_values($payment['house_no']);
         $sanitized_payment = array("id"=>$payment['id'],"created"=>date('d M Y, h:i:sa',strtotime($payment['created'])),"description"=>$payment['name'],"category"=>$payment['category'],"house"=>$house_info[0]['house_no'],"payer"=>$payment['payer']['display_name'],"amount"=>'₹'.$payment['amount'],"mode"=>$payment['mode'],"status"=>$payment['status'], "reference"=>$payment['reference'], "author"=>$payment['author']['display_name'] , "remarks"=>$payment['remarks']);
         array_push($all_sanitized_payments,$sanitized_payment);
         }
    return $all_sanitized_payments;
}
    

 // prepare_items
 public function prepare_items(){
     
     $orderby = isset($_GET['orderby'])?trim($_GET['orderby']):"";
     $order = isset($_GET['order'])?trim($_GET['order']):"";
     
     $search_term = isset($_POST['s'])?trim($_POST['s']):"";
     $data = $this->get_payments_list_data($orderby,$order,$search_term);
     $per_page = 25;
     $current_page = $this->get_pagenum();
     $total_items = count($data);
     
     $this->set_pagination_args(array(
         "total_items"=>$total_items,
         "per_page"=>$per_page
         ));
     
     $this->items = array_slice($data,(($current_page-1)*$per_page), $per_page);
     
     $columns = $this->get_columns();
     $hidden = $this->get_hidden_columns();
     $sortable = $this->get_sortable_columns();
     
     $this->_column_headers = array($columns,$hidden,$sortable);
 }
 
 public function get_hidden_columns(){
     
     return array("reference","status","remarks","description");
 }
 
 public function get_bulk_actions(){
     
     $actions = array(
         
         "exportpdf" => "Export to PDF",
         "exportcsv" => "Export to CSV"
         
         );
        return $actions;
     
 }
 
 public function get_sortable_columns(){
     
     return array(
         "id"=>array("id",false),
         "mode"=>array("mode",false),
         "amount"=>array("amount",false),
         "category"=>array("category",false),
         "created"=>array("created",false)
         );
         
 }
 
 // get_columns
 
 public function get_columns(){
     $columns = array(
         "cb"=>"<input type='checkbox'/>",
         "id"=>"ID",
         "created"=>"Date",
         "description"=>"Description",
         "category"=>"Category",
         "house"=>"House No",
         "payer"=>"Payer",
         "amount"=>"Amount",
         "mode"=>"Payment mode",
         "status"=>"Status",
         "reference"=>"Reference",
         "author"=>"Author",
         "remarks"=>"Remarks",
         "action"=>"Action"
         );
     
     return $columns;
 }
 
 public function column_cb($item){
     
     return sprintf('<input type="checkbox" name="payment[]" value="%s"/>',$item['id']);
 }
 
 // column_defaults
 
 public function column_default($item,$column_name){
     switch($column_name){
         case 'id':
             case 'created':
                 case 'description':
                     case 'category':
                          case 'house':
                         case 'payer':
                             case 'amount':
                                 case 'mode':
                                     case 'status':
                                         case 'reference':
                                             case 'author':
                                                 case 'remarks':
                                                     return $item[$column_name];
                                                     case 'action':
                                                         return "<a href='".get_site_url()."/payment/".$item['id']."/"."'>View</a> | <a href='".get_site_url()."/payment/".$item['id']."/"."'>Edit</a>";
                                                     default:
                                                         return "no value";
     }
 }
}

function nma_show_payments_data_list(){
    
    $nma_list_table = new NMAPaymentsList();

    $nma_list_table->prepare_items();
   
    
    echo '<h1>All Payments</h1>';
    
    echo "<form method='post' name='frm_search_payment' action='".$_SERVER['PHP_SELF']."?page=payments'>";
    $nma_list_table->search_box("Search Payments", "search_payments_id");
    echo "</form>";
    
    $nma_list_table->display();
    
}

nma_show_payments_data_list();