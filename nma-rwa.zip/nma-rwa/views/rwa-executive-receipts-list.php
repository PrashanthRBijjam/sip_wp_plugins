<?php

/*
 * This page contains all function to list the receipts using wp_list_table
 * function
*/

require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');


class NMAReceiptsList extends WP_List_Table{
 
 // define data set for WP_List_Table => data
 
 public function get_list_receipts_data($orderby,$order,$search_term){
     
     if($orderby=='')$receipts_orderby = 'id';
     elseif($orderby=='description')$receipts_orderby = 'name';
     else $receipts_orderby = $orderby;
     
     if($order=='')$receipts_order = 'asc';
     else $receipts_order = $order;
     
     $all_sanitized_receipts = array();
     
     if(!empty($search_term)){
          $receipts = pods('receipt', array('orderby' => $receipts_orderby.' '.$receipts_order, 'limit' => -1, 'where' => 'payer.display_name LIKE "%' . $search_term . '%" OR t.id LIKE "%' . $search_term . '%" OR house_no.house_no LIKE "%' . $search_term . '%" OR amount LIKE "%' . $search_term . '%"'));
     }else {
         $receipts = pods('receipt', array('orderby' => $receipts_orderby.' '.$receipts_order, 'limit' => -1));
     }
     
    
     $all_receipts = $receipts->export_data();
     foreach($all_receipts as $receipt){
         $house_info = array_values($receipt['house_no']);
         $sanitized_receipt = array("id"=>$receipt['id'],"created"=>date('d M Y, h:i:sa',strtotime($receipt['created'])),"description"=>$receipt['name'],"category"=>$receipt['category'],"house"=>$house_info[0]['house_no'],"payer"=>$receipt['payer']['display_name'],"amount"=>'₹'.$receipt['amount'],"status"=>$receipt['status'], "remarks"=>$receipt['remarks']);
         array_push($all_sanitized_receipts,$sanitized_receipt);
         }
    return $all_sanitized_receipts;
}
    

 // prepare_items
 public function prepare_items(){
     
     $orderby = isset($_GET['orderby'])?trim($_GET['orderby']):"";
     $order = isset($_GET['order'])?trim($_GET['order']):"";
     
     $search_term = isset($_POST['s'])?trim($_POST['s']):"";
     $data = $this->get_list_receipts_data($orderby,$order,$search_term);
     $per_page = 25;
     $current_page = $this->get_pagenum();
     $total_items = count($data);
     
     $this->set_pagination_args(array(
         "total_items"=>$total_items,
         "per_page"=>$per_page
         ));
     
     $this->items = array_slice($data,(($current_page-1)*$per_page), $per_page);
     
     $columns = $this->get_columns();
     $hidden = $this->get_hidden_columns();
     $sortable = $this->get_sortable_columns();
     
     $this->_column_headers = array($columns,$hidden,$sortable);
 }
 
 public function get_hidden_columns(){
     
     return array("reference","status","remarks");
 }
 
 public function get_sortable_columns(){
     
     return array(
         "id"=>array("id",false),
         "description"=>array("description",false),
         "amount"=>array("amount",false),
         "category"=>array("category",false),
         "created"=>array("created",false)
         );
         
 }
 
 // get_columns
 
 public function get_columns(){
     $columns = array(
         "id"=>"ID",
         "created"=>"Date",
         "description"=>"Description",
         "category"=>"Category",
         "house"=>"House No",
         "payer"=>"Payer",
         "amount"=>"Amount",
         "status"=>"Status",
         "remarks"=>"Remarks",
         );
     
     return $columns;
 }
 
 // column_defaults
 
 public function column_default($item,$column_name){
     switch($column_name){
         case 'id':
             case 'created':
                 case 'description':
                     case 'category':
                          case 'house':
                         case 'payer':
                             case 'amount':
                                     case 'status':
                                                 case 'remarks':
                                                     return $item[$column_name];
                                                     default:
                                                         return "no value";
     }
 }

}

function nma_show_receipts_data_list(){
    
    $nma_list_table = new NMAReceiptsList();

    $nma_list_table->prepare_items();
   
    
    echo '<h1>All Receipts</h1>';
    
    echo "<form method='post' name='frm_search_receipt' action='".$_SERVER['PHP_SELF']."?page=receipts'>";
    $nma_list_table->search_box("Search receipts", "search_receipts_id");
    echo "</form>";
    
    $nma_list_table->display();
    
}

nma_show_receipts_data_list();