<?php

function nma_admin_welcome_widget(){
    $user = wp_get_current_user();
    $welcome = "Hello, ".$user->display_name;
    
    wp_add_dashboard_widget(
        'SIP_welcome_widget',
        $welcome,
        'sip_welcome_widget_design'
        );
}