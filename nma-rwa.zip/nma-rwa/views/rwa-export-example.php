<?php

require get_template_directory() . '/inc/export_pdf/tcpdf/tcpdf.php';
    
    $pdf = new TCPDF('P', 'pt', 'A4', true, 'UTF-8', false);
            $pdf->SetCreator('');
            $pdf->SetAuthor('');
            $pdf->SetTitle('All Receipts');
            $pdf->SetSubject('');
            $pdf->SetKeywords('');
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);
            $pdf->SetDefaultMonospacedFont('');
            $pdf->SetMargins(10, 10, 10, true);
            $pdf->SetAutoPageBreak(TRUE, 10);
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            $pdf->setLanguageArray($l);
            $pdf->SetDisplayMode('fullpage', 'SinglePage', 'UseNone');
            $pdf->SetTextColor(119, 119, 119);
            $pdf->SetDrawColor(119, 119, 119, false, '');
            $pdf->AddPage('P', 'A4');
     $html = "This is a test html";
     
    $pdf->writeHTML($html, true, false, true, false, ''); 
    $pdf->Output('Receipts.pdf', 'D');

?>