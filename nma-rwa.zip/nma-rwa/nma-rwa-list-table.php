<?php
/*
Plugin Name: Resident Welfare Association RestAPI
Plugin URI:
Description: This is a custom API developed for RWA
Version: 0.1
Author: Prashanth Reddy Bijjam
Author URI: www.needmobile.app
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/
add_action("admin_menu","nma_list_table_menu");


function nma_list_table_menu(){
    add_menu_page("Accounts","Accounts Summary","read_member","member-views","nma_list_table_function","dashicons-welcome-widgets-menus",3);
    add_submenu_page("member-views","Payments", "All Payments","read_member","all-payments","nma_member_list_payments_function",1);
    add_submenu_page("member-views","Receipts", "All Receipts","read_member","all-receipts","nma_member_list_receipts_function",2);
    
    add_menu_page("Executives","Executives","executive_dashboards","executive-view","nma_list_table_function","dashicons-welcome-widgets-menus",4);
    add_submenu_page("executive-view","Payments", "All Payments","executive_dashboards","executive-payments","nma_executive_list_payments_function",1);
    add_submenu_page("executive-view","Receipts", "All Receipts","executive_dashboards","executive-receipts","nma_executive_list_receipts_function",2);
    add_submenu_page("executive-view","Export Receipts", "Export Receipts","executive_dashboards","export-receipts","nma_export_list_receipts_function",3);
    
    add_action("wp_dashboard_setup","nma_call_welcome_widget");
}



function nma_member_list_payments_function(){
    
    ob_start();
    
    include_once plugin_dir_path(__FILE__).'views/rwa-accounts-payments-list.php';
    
    $template = ob_get_contents();
    
    ob_end_clean();
    
    echo $template;
}


function nma_member_list_receipts_function(){
    
    ob_start();
    
    include_once plugin_dir_path(__FILE__).'views/rwa-accounts-receipts-list.php';
    
    $template = ob_get_contents();
    
    ob_end_clean();
    
    echo $template;
}

function nma_executive_list_payments_function(){
    
    ob_start();
    
    include_once plugin_dir_path(__FILE__).'views/rwa-executive-payments-list.php';
    
    $template = ob_get_contents();
    
    ob_end_clean();
    
    echo $template;
}


function nma_executive_list_receipts_function(){
    
    ob_start();
    
    include_once plugin_dir_path(__FILE__).'views/rwa-executive-receipts-list.php';
    
    $template = ob_get_contents();
    
    ob_end_clean();
    
    echo $template;
}

function nma_export_list_receipts_function(){
    
    
    
    ob_start();
    
    include_once plugin_dir_path(__FILE__).'views/rwa-export-example.php';
    
    $template = ob_get_contents();
    
    ob_end_clean();
     
    echo $template;
}


function nma_call_welcome_widget(){
    
    ob_start();
    
    include_once plugin_dir_path(__FILE__).'views/rwa-dashboard-widgets.php';
    
    nma_admin_welcome_widget();
    
    ob_end_clean();
    
}
